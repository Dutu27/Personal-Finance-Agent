import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export async function POST(){
  const url=process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const service=process.env.SUPABASE_SERVICE_ROLE_KEY!;
  if(!url||!service) return NextResponse.json({error:'Server is missing Supabase credentials.'},{status:500});
  const supabase=createClient(url,service,{auth:{autoRefreshToken:false,persistSession:false}});
  const {data,error}=await supabase.functions.invoke('categorize-transactions',{body:{limit:50}});
  if(error) return NextResponse.json({error:error.message},{status:500});
  return NextResponse.json(data);
}
