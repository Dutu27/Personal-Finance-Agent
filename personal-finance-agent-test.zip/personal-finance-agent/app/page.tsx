'use client';
import {useEffect,useState} from 'react';
import {createClient} from '@supabase/supabase-js';

const url=process.env.NEXT_PUBLIC_SUPABASE_URL!;
const key=process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!;
const supabase=createClient(url,key);

export default function Home(){
 const [count,setCount]=useState<number|null>(null); const [categorized,setCategorized]=useState<number|null>(null); const [busy,setBusy]=useState(false); const [log,setLog]=useState('Ready.'); const [receipt,setReceipt]=useState<any>(null);
 const refresh=async()=>{const {count:c}=await supabase.from('transactions').select('*',{count:'exact',head:true});const {count:d}=await supabase.from('transactions').select('*',{count:'exact',head:true}).not('category_id','is',null);setCount(c??0);setCategorized(d??0)};
 useEffect(()=>{refresh()},[]);
 const categorize=async()=>{setBusy(true);setLog('Running AI categorization…');const r=await fetch('/api/categorize',{method:'POST'});const data=await r.json();if(!r.ok){setLog(`ERROR: ${data.error||'Request failed'}`)}else{setLog(JSON.stringify(data,null,2));await refresh()}setBusy(false)};
 const scan=async(file:File)=>{setBusy(true);setReceipt(null);setLog('Reading receipt…');const base64=await new Promise<string>((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=reject;r.readAsDataURL(file)});const r=await fetch('/api/receipt',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({image_base64:base64,filename:file.name})});const data=await r.json();if(!r.ok){setLog(`ERROR: ${data.error||'Request failed'}`)}else{setReceipt(data?.extraction);setLog(JSON.stringify(data,null,2))}setBusy(false)};
 return <main className="wrap"><div className="muted">PERSONAL FINANCE AI · TEST CONSOLE</div><h1>Finance Agent</h1><p className="muted">This is intentionally a test console, not the final UI.</p>
 <div className="grid"><section className="card"><div className="muted">Transactions</div><div className="stat">{count??'—'}</div><p className="muted">{categorized??'—'} categorized</p><button onClick={categorize} disabled={busy||!count}>Categorize up to 50</button></section>
 <section className="card"><div className="muted">Receipt scanner</div><h3>Upload a receipt photo</h3><div className="drop"><input type="file" accept="image/*" disabled={busy} onChange={e=>e.target.files?.[0]&&scan(e.target.files[0])}/></div></section></div>
 {receipt&&<section className="card" style={{marginTop:18}}><h2>Receipt extraction</h2><div className="results"><div className="item"><b>Merchant</b><span>{receipt.merchant_name??'—'}</span><span/></div><div className="item"><b>Date</b><span>{receipt.receipt_date??'—'}</span><span/></div><div className="item"><b>Total</b><span>{receipt.total_amount??'—'} {receipt.currency??''}</span><span/></div></div></section>}
 <section className="card" style={{marginTop:18}}><h2>Last operation</h2><div className="log">{log}</div></section>
 </main>
}
