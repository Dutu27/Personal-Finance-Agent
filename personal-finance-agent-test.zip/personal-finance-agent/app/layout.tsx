import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata={title:'Personal Finance AI — Test Console',description:'Private test console for transaction categorization and receipt scanning'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
